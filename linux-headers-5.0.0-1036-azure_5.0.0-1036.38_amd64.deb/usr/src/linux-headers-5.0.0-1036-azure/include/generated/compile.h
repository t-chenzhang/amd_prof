/* This file is auto generated, version 38-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#38-Ubuntu SMP Sun Mar 22 21:27:21 UTC 2020"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lgw01-amd64-038"
#define LINUX_COMPILER "gcc version 7.5.0 (Ubuntu 7.5.0-3ubuntu1~18.04)"
